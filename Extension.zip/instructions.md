Start => app.js

View feedback in modal (on pressing ]) => showFeedbackReq.js

Handle set requirements button click (add section, hide section, show feedback) => showSetRequirement.js

Insert feedback button click => insertFeedbackBtn.js

manage local storage => localStorage.js

Manage text files => json.js